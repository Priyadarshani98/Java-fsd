package practiceProject4;

public class ParaConstructor {
	

	ParaConstructor(int a,int b){
		int sum = a+b;
		System.out.println("Sum of two nos is "+sum);
	}

}
