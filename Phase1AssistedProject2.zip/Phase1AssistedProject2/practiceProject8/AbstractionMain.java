package practiceProject8;


class CalcImpl extends AbstractionEx{

	@Override
	public void sum(int val1, int val2) {
		// TODO Auto-generated method stub
		System.out.println("Sum is "+(val1+val2));
	}

	@Override
	public void sub(int val1, int val2) {
		// TODO Auto-generated method stub
		System.out.println("Sub is "+(val1-val2));
	}
	
}

public class AbstractionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalcImpl cc = new CalcImpl();
		cc.sum(100,234);
		cc.sub(108,73);
		
	}


}
