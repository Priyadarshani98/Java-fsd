package practiceProject8;

public abstract class AbstractionEx {
	public abstract void sum(int val1,int val2);
	public abstract void sub(int val1,int val2);


}
