package practiceProject5;

import java.util.Scanner;

public class FinallyExe {

	public static void main(String[] args) {
		try {
			int arr[] = new int[4];
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter element to add in array ");
			for(int i=0;i<=5;i++) {
				int val=sc.nextInt();
				arr[i]=val;
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		//Irespective of error occurs or not finally is always got executed.
		finally {
			System.out.println("Thank You !!!");
		}
	}


}
