package practiceProject1;

public class ThreadCreation2 implements Runnable{
	
	public static int count = 0;
	//abstract method
	public ThreadCreation2(){

	}
	
	public void run() {
		while(ThreadCreation2.count <= 10){
			try{
				System.out.println("Exploring Thread: "+(++ThreadCreation2.count));
				Thread.sleep(100);
			} catch (InterruptedException exce) {
				System.out.println("Exception in thread: "+exce.getMessage());
			}
		}
	} 
	
}
