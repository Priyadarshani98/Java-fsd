package practiceProject1;

public class ThreadCreation2Main {
	public static void main(String a[]){
		
		System.out.println("Starting Main Thread...");
		ThreadCreation2 thr = new ThreadCreation2();
		Thread t = new Thread(thr);
		t.start();
		while(ThreadCreation2.count <= 10){
			try{
				System.out.println("Main Thread: "+(++ThreadCreation2.count));
				Thread.sleep(100);
			} catch (InterruptedException exce){
				System.out.println("Exception in main thread: "+exce.getMessage());
			}
		}
		System.out.println("End of Main Thread...");
	}
}
