/**
 * 
 */
/**
 * 
 */
module JDBCdemo {
	requires java.sql;
}