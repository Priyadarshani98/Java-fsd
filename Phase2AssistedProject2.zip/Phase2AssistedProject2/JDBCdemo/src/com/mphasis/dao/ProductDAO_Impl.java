package com.mphasis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dbutil.DbUtil;
import com.mphasis.pojo.Product;

public class ProductDAO_Impl implements ProductDAO{

	@Override
	public int addProduct(Product product) throws ClassNotFoundException, SQLException {
		Connection conn=DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("connected with db...");
		}
		String sql="insert into product values(?,?,?)";
		PreparedStatement st=conn.prepareStatement(sql);
		st.setInt(1, product.getPid());
		st.setString(2,product.getPname());
		st.setInt(3, product.getCost());
		return st.executeUpdate();
	}

	@Override
	public int deleteProduct(int id) throws ClassNotFoundException, SQLException {
		Connection conn = DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("connected with db...");
		}
		String sql="delete from Product where pid=?";
		PreparedStatement st=conn.prepareStatement(sql);
		st.setInt(1, id);
		//Statement st=conn.createStatement();
		//String sql="delete from Product where pid="+id;
		System.out.println("Deleted...");
		return st.executeUpdate();
	}

	@Override
	public int updateProductName(int id, String name) throws ClassNotFoundException, SQLException {
		Connection conn = DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("connected with db...");
		}
		String sql="Update Product SET pname=? where pid=?";
		PreparedStatement st=conn.prepareStatement(sql);
		
		st.setString(1, name);
		st.setInt(2,id);
		
		System.out.println("Data updated...");
		return st.executeUpdate();
	}

	@Override
	public List<Product> selectProducts() throws SQLException, ClassNotFoundException {
		Connection conn=DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("connected with db...");
		}
		Statement st=conn.createStatement();
		String sql="select * from product";
		System.out.println(sql);
		//select we use st.executeQuery
		ResultSet rs=st.executeQuery(sql);
		List<Product> list=new ArrayList<>();
		//it gets the base address of the table 
		while(rs.next()) {  //1st row of the table
			Product product=new Product();
			product.setPid(rs.getInt("pid"));
			product.setPname(rs.getString("pname"));
			product.setCost(rs.getInt("pcost"));
			list.add(product);
		}
		return list;
	}




}
