package practiceProject4;

class Matrix{
	int matrixA[][] = {{1,2,3},{4,5,6}};
	int matrixB[][] = {{-2,-3},{1,-4},{3,4}};

	int row1=2,col1=3;
	int row2=3,col2=2;

	int resultMatrix[][] = new int[row1][col2];

	void product() {
		for(int i=0; i<row1;i++) {
			for(int j=0;j<col2;j++) {
				for(int k=0;k<col1;k++) {
					resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
				}
			}
		}
		System.out.println("The Product of two matrix is :");
		for(int i=0;i<row1;i++) {
			for(int j=0;j<col2;j++) {
				System.out.print(resultMatrix[i][j]+"  ");
			}
			//for new line
			System.out.println();
		}
	}
}

public class MatrixMultiply {
	public static void main(String[] args) {
		Matrix mt = new Matrix();
		mt.product();
	}
}
