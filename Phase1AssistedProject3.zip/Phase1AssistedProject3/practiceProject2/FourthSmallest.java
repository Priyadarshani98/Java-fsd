package practiceProject2;

class Demo{
	int arr[] = new int[]{62,3,8,41,9,2,17}; 
	public void sortArray() {
		int temp=0;
		for(int i=0;i<7;i++) {
			for(int j=i+1;j<7;j++) {
				if(arr[i]>arr[j]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		System.out.println("\nThe Sorted array is ");
		for(int i=0;i<7;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println("\nThe fourth smallest element is "+arr[3]);
	}
}
public class FourthSmallest {
	public static void main(String[] args) {
		Demo obj = new Demo();
		System.out.println("The array is ");
		for(int i=0;i<7;i++) {
			System.out.print(obj.arr[i]+" ");
		}
		obj.sortArray();

	}

}
