package practiceProject2;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {
	public static void main(String[] args) {
		int a[] = new int[] {2,5,8,1,3,6};
		Arrays.sort(a);
		System.out.println("Sorted array is ");
		for(int i:a) {
			System.out.print(i+"  ");
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter element to search ");
		int key = sc.nextInt();
		int flag=0;
		int low=0;
		int high=a.length-1;
		int mid=0;
		while(low<=high) {
			mid=(low+high)/2;
			if(a[mid]==key) {
				flag=1;
				break;
			}
			else if(a[mid]>key) {
				high=mid-1;
			}
			else {
				low=mid+1;
			}
		}
		if(flag==1) {
			System.out.println("Elements found at index "+mid);
		}
		else {
			System.out.println("Elements not found");
		}
	}

}
