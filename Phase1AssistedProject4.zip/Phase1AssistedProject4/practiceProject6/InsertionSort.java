package practiceProject6;

class Sort{
	void insertionSort(int[] arr){
		int len = arr.length;
		for(int j=1;j<len;j++){
			int key = arr[j];
			int i=j-1;
			while ((i>-1) && (arr[i]>key)){

				arr[i+1]=arr[i];
				i--;
			}
			arr[i+1]=key;
		}
	}
}

public class InsertionSort {
	public static void main(String[] args) {
		Sort sort=new Sort();
		int[] arr = {10,3,98,45,7,87};
		System.out.println("Array Before Sort: ");
		for(int i:arr) {
			System.out.print(i+" ");
		}
		sort.insertionSort(arr);
		System.out.println();
		System.out.println("Array After Sort: ");
		for(int i:arr) {
			System.out.print(i+" ");
		}
	}	

}
